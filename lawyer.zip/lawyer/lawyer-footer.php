</div>
</div>

<!-- terms -->
<div class="terms-sec">
	<div class="container"> 
    	<div class="row"> 
        
        	<a href="http://curedincurable.com/rightadvice/terms-of-use">Terms of Use</a> / <a href="http://curedincurable.com/rightadvice/privacy-policy">Privacy Policy</a>  
        
        </div>
    </div>
</div>
<!-- terms end -->


<!-- footer -->
<div class="terms-sec bg-black tec">
	<div class="container"> 
    	<div class="row"> 
        
        	<p>Right Advice Provides its consumers with outstanding advice and professional assistance. It is available AS IS, subject to Terms of Use & Privacy Policy Use for marketing or solicitation is prohibited.</p>
        
        </div>
    </div>
</div>
<!-- footer end -->

</div>
<!-- page-wrapper end -->

<!-- JavaScript files placed at the end of the document so the pages load faster -->
<!-- ================================================== -->
<!-- Jquery and Bootstap core js files -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.1/jquery.form.min.js"></script> 
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js"></script> 

<!-- Modernizr javascript -->
<script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/plugins/modernizr.js"></script>
<!--script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/plugins/jquery.countTo.js"></script-->

<!-- Owl carousel javascript -->
<script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/plugins/owl.carousel.min.js"></script>

<!-- SmoothScroll javascript -->
<script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/plugins/jquery.browser.js"></script>
<script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/plugins/SmoothScroll.js"></script>

<!-- Initialization of Plugins -->
<!--script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/js/template.js"></script-->
<script src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/js/global.js"></script>
<script src="lawyer.js"></script>
<script type="text/javascript" src="http://curedincurable.com/rightadvice/wp-content/themes/right_advice/js/ckeditor/ckeditor.js"></script>
	
<script>
	CKEDITOR.replace( 'editor1' );
</script>
